# Pseudo SO - Trabalho Prático

## Integrantes
Turma: Fundamentos de Sistemas Operacionais - Turma A
1. Alexandre Kaihara (180029690) 
2. Higor Gabriel Azevedo Santos (170012387)
3. Davi Cunha Farias Dupin (170140148)
4. Pedro Luis Chaves Rocha (180054635)


## Requisitos
A linguagem utilizada para esse trabalho foi Python. Todas as dependências e bibliotecas utilizadas nesse trabalho foram apenas aquelas que já vêm baixadas nativamente no Python não tendo a necessidade de se instalar nenhuma biblioteca de terceiros.
A versão Python utilizada para esse trabalho foi python 3.8.2.

## Execução
Primeiramente acesse a pasta onde estão localizados os códigos:
> cd codigo
Para executar esse programa, basta passar como dois argumentos o path para os arquivos .txt dos processos e .txt dos files como segue abaixo:
> python main.py processes.txt files.txt

